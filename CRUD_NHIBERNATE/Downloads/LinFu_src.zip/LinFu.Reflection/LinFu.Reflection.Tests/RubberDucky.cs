using System;
using System.Collections.Generic;
using System.Text;

namespace LinFu.Reflection.Tests
{
    public class RubberDucky
    {
        public void Quack()
        {
            Console.WriteLine("Quack, quack!");
        }
    }
}
