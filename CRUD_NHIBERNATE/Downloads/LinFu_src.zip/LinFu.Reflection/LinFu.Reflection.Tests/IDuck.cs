using System;
using System.Collections.Generic;
using System.Text;

namespace LinFu.Reflection.Tests
{
    public interface IDuck
    {
        void Quack();
    }
}
