using System;
using System.Collections.Generic;
using System.Text;

namespace LinFu.Reflection.Tests
{
    public delegate int IntegerOperation(int a, int b);
}
