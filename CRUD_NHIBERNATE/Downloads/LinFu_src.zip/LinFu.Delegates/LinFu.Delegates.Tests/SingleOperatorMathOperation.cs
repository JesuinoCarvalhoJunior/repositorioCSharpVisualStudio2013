using System;
using System.Collections.Generic;
using System.Text;

namespace LinFu.Delegates.Tests
{
    public delegate int SingleOperatorMathOperation(int a);    
}
