using System;
using System.Collections.Generic;
using System.Text;

namespace LinFu.Delegates.Tests
{
    public delegate int MathOperation(int a, int b);
}
