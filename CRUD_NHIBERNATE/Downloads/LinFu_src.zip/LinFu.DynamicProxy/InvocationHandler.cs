namespace LinFu.DynamicProxy
{
    public delegate object InvocationHandler(InvocationInfo info);
}