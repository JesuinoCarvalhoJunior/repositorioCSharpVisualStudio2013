﻿using System;
using System.Windows.Forms;
using PrimeraAplicacaoNHibernate.Telas;

namespace PrimeraAplicacaoNHibernate
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormularioPrincipal());
        }
    }
}
