namespace PrimeraAplicacaoNHibernate.Controladores
{
    public interface IControladorDaTelaFormularioPrincipal
    {
        void UsuarioClicouNoBotaoDeCategoria();
        void UsuarioClicouNoBotaoDePessoa();
    }
}