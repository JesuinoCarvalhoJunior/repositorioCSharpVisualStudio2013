namespace PrimeraAplicacaoNHibernate.Telas
{
    public interface IFormularioPrincipal
    {
        void MostreTelaDeCategoria();
        void MostreTelaDePessoa();
    }
}