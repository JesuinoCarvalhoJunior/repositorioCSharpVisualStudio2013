namespace PrimeraAplicacaoNHibernate.Telas
{
    public interface IFormularioBasico
    {
        void MostreMensagemDeAtencao(string mensagem);
        void MostreMensagemDeErro(string mensagem);
    }
}